package com.example.quizgame;
import android.util.Log;


public class Question {
    private
        String question;
        String[] answers;
        int correctAnswer;

    public Question(String question, String[] answers, int correctAnswer){
        if(answers.length == 4) {
            this.question = question;
            this.correctAnswer = correctAnswer;
            this.answers = new String[4];
            this.answers[0] = answers[0];
            this.answers[1] = answers[1];
            this.answers[2] = answers[2];
            this.answers[3] = answers[3];
        }else{
            Log.i("1","Wrong number of answers!");
        }
    }

    public String getQuestion() {
        return question;
    }

    public String[] getAnswers() {
        return answers;
    }

    public int getCorrectAnswer() {
        return correctAnswer;
    }


}
