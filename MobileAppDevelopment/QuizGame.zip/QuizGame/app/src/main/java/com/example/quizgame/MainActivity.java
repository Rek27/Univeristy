package com.example.quizgame;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    QuestionRepository questionRepository = new QuestionRepository();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //hard-code the questions
        questionRepository.createQuestions();

        //show random question
        nextQuestion();
    }
    public void nextQuestion(){

        //get the random question from pool of questions
        Question question = questionRepository.randomQuestion();


        //Put the text(question) in TextView
        TextView questionText = findViewById(R.id.id_question);
        questionText.setText(question.getQuestion());

        //enable every buttton and put text inside
        Button btn = findViewById(R.id.id_a1);
        btn.setEnabled(true);
        btn.setText(question.getAnswers()[0]);

        btn = findViewById(R.id.id_a2);
        btn.setEnabled(true);
        btn.setText(question.getAnswers()[1]);

        btn = findViewById(R.id.id_a3);
        btn.setEnabled(true);
        btn.setText(question.getAnswers()[2]);

        btn = findViewById(R.id.id_a4);
        btn.setEnabled(true);
        btn.setText(question.getAnswers()[3]);
    }

    public void buttonIsClicked(View view){
        Button clickedButton = (Button)view;
        if(clickedButton.getText() == questionRepository.getCurrentQuestion().answers[questionRepository.getCurrentQuestion().getCorrectAnswer()]){
            nextQuestion();
        }else{
            clickedButton.setEnabled(false);
        }

    }
}