package com.example.quizgame;

import java.util.ArrayList;
import java.util.Random;

public  class QuestionRepository {

    private ArrayList<Question> listOfQuestions = new ArrayList<Question>();
    private int idCurrentQuestion;


    public Question getCurrentQuestion() {
        return listOfQuestions.get(idCurrentQuestion);
    }

    public int getIdCurrentQuestion() {
        return idCurrentQuestion;
    }

    public void createQuestions(){
        listOfQuestions.add(new Question("What's 9 + 10?", new String[]{"1", "19", "21", "23"}, 2));
        listOfQuestions.add(new Question("In which city is Einstein born?", new String[]{"Berlin", "Munich", "Ulm", "Frankfurt"}, 2));
        listOfQuestions.add(new Question("What is the speed of sound?", new String[]{"1200 km/h", "400 km/h", "2000 km/h", "700 km/h"}, 0));
        listOfQuestions.add(new Question("How many time zones are there in total in the world?", new String[]{"16", "8", "32", "24"}, 3));
    }

    public Question randomQuestion(){
        Random random = new Random();
        int id = random.nextInt(listOfQuestions.size());
        this.idCurrentQuestion = id;
        return listOfQuestions.get(id);
    }


}
