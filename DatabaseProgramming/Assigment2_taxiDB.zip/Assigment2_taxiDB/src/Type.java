
import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.TableGenerator;

//Class 'Type' that represents 'Type' table in the DB

@Entity
public class Type {
	@Id
	@Basic(optional=false)
	@Column(name="IDTYPE")
	@GeneratedValue(strategy = GenerationType.TABLE,generator = "typeGenerator")
	@TableGenerator(name = "typeGenerator",table = "ID_GEN",pkColumnName = "GEN_KEY",valueColumnName = "GEN_VALUE",pkColumnValue = "TYPE_ID",allocationSize = 1)
	private int id;		//IDTYPE(primary key)
	
	@Basic(optional=false)
	@Column(name="MANUFACTURER", columnDefinition="CHAR(45)")
	private String manufacturer;	//Manufacturer
	
	@Basic(optional=false)
	@Column(name="MODEL", columnDefinition="CHAR(45)")
	private String modelname;	//Name of the model
	
	@Basic(optional=false)
	@Column(name="NOSEATS", columnDefinition="TINYINT UNSIGNED")
	private int noSeats;	//Number of seats 
	
	
	// Getters and Setters
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public String getModelname() {
		return modelname;
	}
	public void setModelname(String modelname) {
		this.modelname = modelname;
	}
	public int getNoSeats() {
		return noSeats;
	}
	public void setNoSeats(int noSeats) {
		this.noSeats = noSeats;
	}

		
}
