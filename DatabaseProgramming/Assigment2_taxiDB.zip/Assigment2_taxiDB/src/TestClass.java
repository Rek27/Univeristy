
import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.ArrayList;

import java.sql.Timestamp;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;

public class TestClass {
	private static final String PERSISTENCE_UNIT_NAME = "taxi";
    private static EntityManagerFactory factory;
    
	public static void main(String[] args) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		//Creating some objects
		Type type = new Type();
		type.setManufacturer("BMW");
		type.setModelname("X5");
		type.setNoSeats(5);
		
		Vehicle vehicle2 = new Vehicle();
		vehicle2.setMilage("120000");
		vehicle2.setRegistred(Date.valueOf("2021-01-31"));
		
		Vehicle vehicle1 = new Vehicle();
		vehicle1.setMilage("90500");
		vehicle1.setRegistred(Date.valueOf("2020-06-19"));
		
		Taxidriver driver1 = new Taxidriver();
		driver1.setFirstname("Peter");
		driver1.setName("White");
		driver1.setMobile("+491234567890");
		
		Taxidriver driver2 = new Taxidriver();
		driver2.setFirstname("Mark");
		driver2.setName("Lukas");
		driver2.setMobile("+498934565434");
		
		Booking booking1 = new Booking();
		booking1.setBookingTime(Timestamp.valueOf("2021-07-12 21:30:56.000"));
		booking1.setDistance(2.35);
		booking1.setDuration(13);
		
		Booking booking2 = new Booking();
		booking2.setBookingTime(Timestamp.valueOf("2021-03-30 17:33:23.000"));
		booking2.setDistance(1.98);
		booking2.setDuration(10);
		
		//Establishing relationships
		vehicle1.setType_idType(type);
		vehicle2.setType_idType(type);
		
		booking1.setVehicle(vehicle1);
		vehicle1.addBooking(booking1);
		
		booking2.setVehicle(vehicle2);
		vehicle2.addBooking(booking2);
		
		booking1.setDriver(driver1);
		driver1.addBooking(booking1);
		
		booking2.setDriver(driver2);
		driver2.addBooking(booking2);
		
		//Persisting and commiting
		em.persist(booking1);
		em.persist(booking2);
		em.getTransaction().begin();
		em.getTransaction().commit();	
		
		
		//Queries
		TypedQuery<Booking> tq1 = em.createNamedQuery("findVehicleByBookingTime", Booking.class);
		tq1.setParameter("bookingTime", Timestamp.valueOf("2021-07-12 21:30:56.000"));
		List returnedVehicles = tq1.getResultList();
		System.out.println("Vehicles that were used at the given time: ");
		for(int i = 0;i<returnedVehicles.size();i++) {
			Vehicle v1 = (Vehicle)(returnedVehicles.get(i));
			System.out.println(v1.getId() + ", " + v1.getMilage() + ", " + v1.getRegistred());
		}
		
		
		TypedQuery<Taxidriver> tq2 = em.createNamedQuery("findBookingsByDriverName", Taxidriver.class);
		tq2.setParameter("name", "White");
		List returnedBookings = tq2.getResultList();
		System.out.println("Bookings that drivers with name 'White' drove: ");
		for(int i = 0;i<returnedBookings.size();i++) {
			Booking b1 = (Booking)(returnedBookings.get(i));
			if(b1 != null) {
				System.out.println(b1.getId() + ", " + b1.getDuration() + ", " + b1.getDistance());
			}
		}
	}
}
