
import jakarta.persistence.Basic;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.TableGenerator;

import java.sql.Timestamp;

//Named query that finds a vehicle that drove in the given timestamp
@NamedQuery(name="findVehicleByBookingTime", 
	query="SELECT b.vehicle FROM Booking b WHERE b.bookingTime = :bookingTime")

//Class 'Booking' that represents 'BOOKING' table in the DB

@Entity
@Table(name="BOOKING")
public class Booking {
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE,generator = "bookingGenerator")
	@TableGenerator(name = "bookingGenerator",table = "ID_GEN",pkColumnName = "GEN_KEY",valueColumnName = "GEN_VALUE",pkColumnValue = "BOOKING_ID",allocationSize = 1)
	@Column(name="IDBOOKING")
	@Basic(optional=false)
	private int id;		//IDBOOKING(primary key)

	@Column(name="DISTANCEINKM", columnDefinition="DECIMAL(5,2)")
	@Basic(optional=false)
	private double distance;	//Distance that car drove
	
	@Column(name="TIMEINMIN")
	@Basic(optional=false)
	private int duration;		//Time duration that car drove
	
	@Column(name="BOOKINGTIME")
	@Basic(optional=false)
	private Timestamp bookingTime;	//Time when the car started driving

	//Booking is in ManyToOne bi-directional relatonship with Vehicle
	//cascade is the type of PERSIST because if we persist a Booking, vehicle should be persisted as well
	@ManyToOne(optional=true, cascade=CascadeType.PERSIST)
	@JoinColumn(name="CAR_IDCAR")
	private Vehicle vehicle;
	
	//Booking is in ManyToOne bi-directional relatonship with Taxidriver
	//cascade is the type of PERSIST because if we persist a Booking, driver should be persisted as well
	@ManyToOne(optional=true, cascade=CascadeType.PERSIST)
	@JoinColumn(name="DRIVER_IDDRIVER")
	private Taxidriver driver;
	
	//Setters and Getters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getDistance() {
		return distance;
	}

	public void setDistance(double distance) {
		this.distance = distance;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public Timestamp getBookingTime() {
		return bookingTime;
	}

	public void setBookingTime(Timestamp bookingTime) {
		this.bookingTime = bookingTime;
	}
	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	public Taxidriver getDriver() {
		return driver;
	}

	public void setDriver(Taxidriver driver) {
		this.driver = driver;
	}
}
