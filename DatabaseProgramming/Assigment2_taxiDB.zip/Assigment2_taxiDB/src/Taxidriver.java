
import jakarta.persistence.Basic;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.TableGenerator;

import java.util.List;
import java.util.ArrayList;

//Named query that finds all Bookings that driver with a given name did
@NamedQuery(name="findBookingsByDriverName", 
query="SELECT t.bookings FROM Taxidriver t WHERE t.name = :name")

//Class 'Taxidriver' that represents 'DRIVER' table in the DB

@Entity
@Table(name="DRIVER")
public class Taxidriver {
	
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE,generator = "driverGenerator")
	@TableGenerator(name = "driverGenerator",table = "ID_GEN",pkColumnName = "GEN_KEY",valueColumnName = "GEN_VALUE",pkColumnValue = "DRIVER_ID",allocationSize = 1)
	@Basic(optional=false)
	@Column(name="IDDRIVER")
	private int id;		//IDDRIVER(primary key)
	
	@Basic(optional=false)
	@Column(columnDefinition="CHAR(45)", name="SURNAME")
	private String name;	//Last name of the driver
	
	@Basic(optional=false)
	@Column(columnDefinition="CHAR(45)", name="FIRSTNAME")
	private String firstname;	//First name of the driver
	
	@Basic(optional=false)
	@Column(columnDefinition="CHAR(45)", name="MOBILE")
	private String mobile;	//Mobile number of the driver
	
	
	//Taxidriver is in the bi-directional relationship with Booking
	//orphanRemoval is true because if driver is deleted, all his booking are left without a driver and should be deleted as well
	//cascade is PERSIST type because if we persist a driver, all his booking should be persisted as well
	@OneToMany(mappedBy="driver", orphanRemoval=true, cascade = CascadeType.PERSIST)
	private List <Booking> bookings = new ArrayList<Booking>(); 
	
	//Setters and Getters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public List<Booking> getBookings() {
		return bookings;
	}

	public void setBookings(List<Booking> bookings) {
		this.bookings = bookings;
	}
	 public void addBooking(Booking booking) {
		 bookings.add(booking);
	 }
}
