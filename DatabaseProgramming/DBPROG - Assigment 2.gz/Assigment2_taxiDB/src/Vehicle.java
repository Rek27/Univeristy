
import jakarta.persistence.Basic;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.TableGenerator;

import java.sql.Date;
import java.util.List;
import java.util.ArrayList;

//Class 'Vehicle' that represents 'CAR' table in the DB

@Entity
@Table(name="CAR")
public class Vehicle {
	@Id
	@Basic(optional=false)
	@Column(name="IDCAR")
	@GeneratedValue(strategy = GenerationType.TABLE,generator = "vehicleGenerator")
	@TableGenerator(name = "vehicleGenerator",table = "ID_GEN",pkColumnName = "GEN_KEY",valueColumnName = "GEN_VALUE",pkColumnValue = "IDCAR",allocationSize = 1)
	private int id;		//IDCAR(primary key)
	
	@Basic(optional=false)
	@Column(name="MILAGE", columnDefinition="CHAR(45)")
	private String milage;	//Milage of the car
	
	@Basic(optional=false)
	@Column(name="REGISTERDATE")
	private Date registred;	//Date of the registration of the car
	
	//Vehicle is in the ManyToOne uni-directional relationship with Type
	//cascade is type PERSIST because if we persist a Vehicle, Type should be persisted as well
	@ManyToOne(optional = false, cascade=CascadeType.PERSIST)
	@JoinColumn(name="TYPE_IDTYPE")
	private Type type_idType;
	
	//Vehicle is in the OneToMany bi-directional relationship with Booking
	//orphanRemoval is true because if we delete some Vehicle and some Bookings are left without a relationship, they should be deleted
	@OneToMany(mappedBy="vehicle", orphanRemoval=true)
	private List<Booking> bookings = new ArrayList<Booking>();
	
	//Getters and Setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMilage() {
		return milage;
	}

	public void setMilage(String milage) {
		this.milage = milage;
	}

	public Date getRegistred() {
		return registred;
	}

	public void setRegistred(Date registred) {
		this.registred = registred;
	}

	public Type getType_idType() {
		return type_idType;
	}

	public void setType_idType(Type type_idType) {
		this.type_idType = type_idType;
	}

	public List<Booking> getBookings() {
		return bookings;
	}

	public void setBookings(List<Booking> bookings) {
		this.bookings = bookings;
	}
	
	public void addBooking(Booking booking) {
		bookings.add(booking);
	}
}
